﻿using Aron.Sinoai.OfficeHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static String GENERATED_FILE_NAME = @"c:\work\generated.xlsx";
        private static String TEMPLATE_FILE_NAME = @"c:\work\template.xlsx";

        private void button1_Click(object sender, EventArgs e)
        {
            createGeneratedFile();
            openGeneratedFile();
        }

        private IEnumerable<List<object>> getSample()
        {
            var random = new Random();

            for (int loop = 0; loop < 3000; loop++)
            {
                yield return new List<object> { "test", DateTime.Now.AddDays(random.NextDouble() * 100 - 50), loop };
            }

        }

        private void createGeneratedFile()
        {
            using (ExcelHelper helper = new ExcelHelper(TEMPLATE_FILE_NAME, GENERATED_FILE_NAME))
            {
                helper.Direction = ExcelHelper.DirectionType.TOP_TO_DOWN;

                helper.CurrentSheetName = "Sheet1";

                helper.CurrentPosition = new CellRef("C3");

                //the template xlsx should contains the named range "header"; use the command "insert"/"name".
                helper.InsertRange("header");

                //the template xlsx should contains the named range "sample1";
                //inside this range you should have cells with these values:
                //<name> , <value> and <comment>, which will be replaced by the values from the getSample()
                CellRangeTemplate sample1 = helper.CreateCellRangeTemplate("sample1", new List<string> { "name", "value", "comment" });

                helper.InsertRange(sample1, getSample());

                //you could use here other named ranges to insert new cells and call InsertRange as many times you want, 
                //it will be copied one after another;
                //even you can change direction or the current cell/sheet before you insert

                //tipically you put all your "template ranges" (the names) on the same sheet and then you just delete it
                helper.DeleteSheet("Sheet3");
            }
        }

        private void openGeneratedFile()
        {
            System.Diagnostics.Process.Start(GENERATED_FILE_NAME);
        }

    }
}
